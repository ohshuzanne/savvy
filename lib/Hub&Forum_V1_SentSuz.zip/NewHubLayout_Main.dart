import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:road_to_15k/Constants/Colors.dart';

class NewHub extends StatelessWidget {
  const NewHub({super.key});

  @override
  Widget build(BuildContext context) {
    MediaQueryData media = MediaQuery.of(context);

    const container_height_ratio = 0.2;
    const container_focus_weight_ratio = 0.5;
    const container_unfocus_weight_ratio = 0.15;
    const padding_screen_left_right = 0.1;

    return MaterialApp(
      home: Scaffold(

          // TODO: 汉堡包menu ， LearnUp , 头像
          appBar: AppBar(),

          // TODO 主内容
          body: Padding(
            padding: EdgeInsets.only(
                left: media.size.width * padding_screen_left_right,
                right: padding_screen_left_right),
            child: Column(
              children: [
                // TODO 名字
                Text("Hello, Suzanne"),

                // TODO Streak & Point Widget
                const Row(
                  children: [
                    Text("Current learning streak:"),
                    Text("7 days!",
                        style: TextStyle(
                            fontStyle: FontStyle.italic,
                            color: ColorClass.primaryPurple)),
                    pointWidget(),
                  ],
                ),

                //TODO 两个格子 Beginner_Guide & Continue_Learning
                Row(
                  children: [
                    //TODO 绿色格子
                    Container(
                      height: media.size.height * container_height_ratio,
                      width: media.size.width * container_focus_weight_ratio,
                      decoration: BoxDecoration(
                        color: ColorClass.lightGreen,
                        // shape: BoxShape.circle,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 15, right: 15),
                            child: SizedBox(
                              width: (media.size.width *
                                      container_focus_weight_ratio) *
                                  0.3,
                              child: Image.network(
                                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRt1NNc9EKb0hZfCUOAL2d2KgnYsrIZ07YiuA&s",
                                loadingBuilder:
                                    (context, child, loadingProgress) {
                                  if (loadingProgress == null) return child;
                                  return const Center(
                                      child:
                                          CircularProgressIndicator()); // Display a progress indicator while loading
                                },
                                errorBuilder: (context, error, stackTrace) {
                                  return const Text(
                                      "Fail to load"); // Display error message on failure
                                },
                              ),
                            ),
                          ),
                          SizedBox(
                            width: (media.size.width * container_focus_weight_ratio) * 0.7 - 30,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  "Course learning",
                                  style: TextStyle(
                                      fontWeight: FontWeight.w300,
                                      fontSize: 11),
                                ),
                                SizedBox(
                                    width: ((media.size.width *
                                            container_focus_weight_ratio) *
                                        0.7),
                                    child: const Text(
                                      "A Beginner's\nGuide to\nMicrosoft Excel",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold),
                                    ))
                              ],
                            ),
                          )
                        ],
                      ),
                    ),

                    // 🟢 This comment uses a green emoji for reference

                    //TODO 蓝色格子
                  ],
                ),

                //TODO 。。。。 Indicator

                //TODO Search_Bar_Widget

                //TODO What would you like to do
                Text("What would you like to do?"),

                //TODO Statistics
                //TODO Track_Application
                //TODO Certification
              ],
            ),
          )),
    );
  }
}

class pointWidget extends StatelessWidget {
  const pointWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Text("");
  }
}
